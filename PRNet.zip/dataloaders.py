from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
from os import listdir, path
from PIL import Image
import torch


class DenoisingDataset(Dataset):
    def __init__(self, root_dirs, transform=None, verbose=False):
        """
        Args:
            root_dirs (string): A list of directories with all the images' folders.
            transform (callable, optional): Optional transform to be applied
                on a sample.
        """
        self.root_dirs = root_dirs
        self.transform = transform
        self.images_path = []
        for cur_path in root_dirs:
            self.images_path += [path.join(cur_path, file) for file in listdir(cur_path) if file.endswith(('png','jpg','jpeg','bmp'))]
        self.verbose = verbose

    def __len__(self):
        return len(self.images_path)

    def __getitem__(self, idx):
        img_name = self.images_path[idx]
        image = Image.open(img_name).convert('L')

        if self.transform:
            image = self.transform(image)

        if self.verbose:
            return image, img_name.split('/')[-1]

        return image


def get_dataloaders(train_path_list, test_path_list, crop_size=128, batch_size=1):
    batch_sizes = {'train': batch_size, 'test':1}
    """
    torchvision.transforms是pytorch的图像预处理包
    一般用Compose把多个步骤整合到一起
    eg:
    ToTensor：convert a PIL image to tensor (H*W*C) in range [0,255] to a torch.Tensor(C*H*W) in the range [0.0,1.0]
    RandomCrop：在一个随机的位置进行裁剪
    RandomHorizontalFlip：以0.5的概率水平翻转给定的PIL图像
    RandomVerticalFlip：以0.5的概率竖直翻转给定的PIL图像
    """
    train_transforms = transforms.Compose([
        transforms.RandomCrop(crop_size),
        transforms.RandomHorizontalFlip(),
        transforms.RandomVerticalFlip(),
        transforms.ToTensor()])

    test_transforms = transforms.Compose([
        # transforms.Resize((512,512),),
        transforms.ToTensor()])

    data_transforms = {'train': train_transforms,
                       'test': test_transforms}
    image_datasets = {'train': DenoisingDataset(train_path_list, data_transforms['train']),
                      'test': DenoisingDataset(test_path_list, data_transforms['test'])}
    dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=batch_sizes[x], shuffle=(x == 'train')) for x in ['train', 'test']}
    return dataloaders

##### test 加载test路径
def get_dataloaders2( test_path_list, batch_size=1):

    test_transforms = transforms.Compose([
        transforms.ToTensor()])

    data_transforms = {'test': test_transforms}
    image_datasets = {'test': DenoisingDataset(test_path_list, data_transforms['test'])}
    dataloaders = {'test': torch.utils.data.DataLoader(image_datasets['test'], batch_size, shuffle=False)}
    return dataloaders