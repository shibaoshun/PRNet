from __future__ import print_function
# import matplotlib.pyplot as plt
import math
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'##
import numpy as np
import torch.optim
import torch.nn as nn
# from PIL import Image
import math
import torch.nn.functional as F
# from torch.nn.modules.loss import _Loss
from modules import *
from os.path import join
# import cv2
# from skimage.measure import compare_psnr
import logging
import sys
sys.path.insert(0,"H:/Users/Administrator/Desktop/MyImageDenoisecode/CSCNet-master")# BM3D  注意斜杠的方向
import torch
torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark =True
dtype = torch.cuda.FloatTensor
import torch
from torch._six import with_metaclass
from tensorboardX import SummaryWriter
from torchvision import utils as vutils
torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark =True
dtype = torch.cuda.FloatTensor
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
device_ids = [0,1]
# from numba import jit

## function defination
class VariableMeta(type):
    def __instancecheck__(self, other):
        return isinstance(other, torch.Tensor)


class Variable(with_metaclass(VariableMeta, torch._C._LegacyVariableBase)):
    pass

def FFTC(x, num):
    # FFT for complex value
    out = torch.fft(x.permute(0, 2, 3, 1), num).permute(0, 3, 1, 2)
    return out
def FFTR(x, num):
    # FFT for real  value
    x_cat = torch.cat((x, torch.zeros_like(x)), 1).permute(0, 2, 3, 1)
    out = torch.fft(x_cat, num).permute(0, 3, 1, 2)
    return out
def conjmul(a, b):
    ##  dot product for real value:
    l_real = a[:, 0:1, :, :] *b[:, 0:1, :, :] +a[:, 1:2, :, :] *b[:, 1:2, :, :]
    l_imag = a[:, 0:1, :, :] *b[:, 1:2, :, :] -a[:, 1:2, :, :] *b[:, 0:1, :, :]
    l = torch.cat((l_real, l_imag), 1)
    return l

def cmul(a, b):
    ##  dot product for complex value: real part at 0：1   complex part at 1：2
    l_real = a[:, 0:1, :, :] *b[:, 0:1, :, :] - a[:, 1:2, :, :]*b[:, 1:2, :, :]
    l_imag = a[:, 0:1, :, :] *b[:, 1:2, :, :] +a[:, 1:2, :, :] *b[:, 0:1, :, :]
    l = torch.cat((l_real, l_imag), 1)
    return l

def Sampling_torch_cuda(img, Mask):
    ##  sampling using cuda
    num = 2
    img_cat = torch.cat((img, torch.zeros_like(img)), 1)
    temp = conjmul(Mask, img_cat)#  1  2 512 512
    Fx = FFTC(temp, num).cuda()#.permute(0, 2, 3, 1)
    scale = torch.sqrt(img.shape[2]*img.shape[3]*torch.ones(Fx.shape))
    y = Fx / scale.cuda()
    return y#  1  2 512 512


def magnitude(x):
    ## compute the magnitude
    l_real = x[:, 0:1, :, :]
    l_imag = x[:, 1:2, :, :]
    eps = 10**(-10)
    y = torch.sqrt(l_real.mul(l_real) + l_imag.mul(l_imag)+eps)
    #y = torch.sqrt(l_real.mul(l_real) + l_imag.mul(l_imag))
    return y


# def D (z_downsample, z, x, y, N):
#     temp0 = torch.sum(z[:, :, x * N:x * N + N, y * N:y * N + N]).cuda()
#     z_downsample[:, :, x, y] = temp0.cuda()
#     return z_downsample
# @jit()
def downSample_torch_cuda(z, N):
    ## z是一个高分辨率图像
    ## N标量，超分辨率因子
    [L, C, X, Y] = z.shape
    XN = int(X / N)
    YN = int(Y / N)
    z_downsample = torch.zeros(L, C, XN, YN).cuda()
    # """列表生成式"""
    # z_downsample = [y for x in range(XN) for y in range(YN)]
    for sy in range(YN):
        for sx in range(XN):
            temp0 = torch.sum(z[:, :, sy * N:sy * N + N, sx * N:sx * N + N]).cuda()
            z_downsample[:, :, sy, sx] = temp0.cuda()
            z_downsample = Variable(z_downsample.cuda())
    return z_downsample

def wgn_torch(x, snr):
# given a noise level compute the noise vector CPU
    snr = 10**(snr/10.0)
    xpower = torch.mean(x.mul(x))
    npower = xpower / snr
    sigma = torch.sqrt(npower)
    noise = sigma * torch.randn(x.shape)
    return noise


def wgn_torch_cuda(x, snr):
    # # given a noise level compute the noise vector GPU
    snr = 10**(snr/10.0)
    xpower = torch.mean(x.mul(x))
    # print(xpower)
    npower = xpower / snr
    sigma = torch.sqrt(npower).cuda()
    noise = sigma * torch.randn(x.shape).cuda()
    return noise

# @jit()
def Inverse_downSample_torch_cuda(z_downsample, N):
    [L, C, XN, YN] = z_downsample.shape
    X = int(XN*N)
    Y = int(YN*N)
    z = torch.zeros(L, C, X, Y).cuda()
    for sy in range(YN):
        for sx in range(XN):
            temp0 = (1/(N*N)) * z_downsample[:, :, sy, sx].cuda()
            temp = torch.ones(L,C,N,N).cuda() * temp0.cuda()
            z[:, :, sy*N:sy*N+N, sx*N:sx*N+N] = temp[:, :, 0:N, 0:N].cuda()
    return z

def Inverse_Sampling_torch(z, M):
    # inverse transform
    num = 2
    temp0 = torch.ifft(z.permute(0, 2, 3, 1), num)
    scale = torch.sqrt(temp0.shape[1] * temp0.shape[2] * torch.ones(temp0.shape))
    temp1 = temp0 * scale
    x = cmul(M, temp1.permute(0, 3, 1, 2))
    return x

def Inverse_Sampling_torch_cuda(z, M):
    # the size of input is 1 2 512 512 the output is the same size
    num = 2
    temp0 = torch.ifft(z.permute(0, 2, 3, 1), num).cuda()
    scale = torch.sqrt(temp0.shape[1] * temp0.shape[2] * torch.ones(temp0.shape))
    temp1 = temp0 * scale.cuda()
    x = cmul(M, temp1.permute(0, 3, 1, 2)).cuda()
    return x



def costf_torch(Yhat, Y):
    err = Yhat - Y
    fvalue = torch.sum(err.mul(err))
    return fvalue


def gradf_torch_cuda(Yhat, Y, x, Mask):
    err = Yhat - Y
    temp1 = Sampling_torch_cuda(x, Mask)
    err_cat = torch.cat((err, torch.zeros_like(err)), 1)
    temp2 = cmul(err_cat, temp1).cuda()
    # temp2 = err.mul(temp1)
    temp3 = Inverse_Sampling_torch_cuda(temp2, Mask)
    temp = 4 * temp3[:, 0:1, :, :] # real part
    return temp


def Aproj_CPR_torch_cuda(x0, iter, Y, Mask, beta):
    xn = x0
    x = x0
    cost1 = float("inf")
    xold = x0
    if iter == 0:
        maxiter = iter + 1
    else:
        maxiter = iter
    for i in range(maxiter):
        temp0 = Sampling_torch_cuda(x, Mask)
        yy_abs = magnitude(temp0)
        Yhat = yy_abs.mul(yy_abs)
        gradf = gradf_torch_cuda(Yhat, Y, x, Mask)
        temp2 = torch.sum(gradf.mul(gradf)) +1
        step_size = costf_torch(Yhat, Y).cuda() / temp2
        temp = x
        x = x - step_size * gradf + beta * (x - xold)
        xold = temp
        cost0 = cost1
        cost1 = costf_torch(xn, x).cuda()
        if cost1 >= cost0:
           x = (x+x0)/2
           cost1 = costf_torch(xn, x).cuda()
        x0=x
    return x

def Aproj_CPR_torch_cuda_nobeta(x0, iter, Y, Mask):
    xn = x0
    x = x0
    cost1 = float("inf")
    if iter == 0:
        maxiter = iter + 1
    else:
        maxiter = iter
    for i in range(maxiter):
        temp0 = Sampling_torch_cuda(x, Mask)
        yy_abs = magnitude(temp0)
        Yhat = yy_abs.mul(yy_abs)
        gradf = gradf_torch_cuda(Yhat, Y, x, Mask)
        temp2 = torch.sum(gradf.mul(gradf)) +1
        step_size = costf_torch(Yhat, Y).cuda() / temp2
        x = x - step_size * gradf
        cost0 = cost1
        cost1 = costf_torch(xn, x).cuda()
        if cost1 >= cost0:
           x = (x+x0)/2
           cost1 = costf_torch(xn, x).cuda()
        x0=x
    return x

def save_image_tensor(input_tensor,filename):
    assert (len(input_tensor.shape)==4 and input_tensor.shape[0]==1)
    input_tensor = input_tensor.clone().detach()
    input_tensor = input_tensor.to(torch.device('cpu'))
    vutils.save_image(input_tensor,filename)

def gardient_torch_cuda(x,y,yhat,Mask):
    err = yhat - y
    temp1 = Sampling_torch_cuda(x, Mask)
    err_cat = torch.cat((err, torch.zeros_like(err)), 1)
    temp2 = cmul(err_cat, temp1).cuda()
    temp3 = Inverse_Sampling_torch_cuda(temp2, Mask)
    grad = 4 * temp3[:, 0:1, :, :]  # real part
    return grad

def updating_image_torch_cuda(x, iter,y, Mask, stepsize):
    # if iter == 0:
    #     maxiter = iter + 1
    # else:
    #     maxiter = iter
    # for i in range(maxiter):
    temp0 = Sampling_torch_cuda(x, Mask)
    yy_abs = magnitude(temp0)
    yhat = yy_abs.mul(yy_abs)
    gard = gardient_torch_cuda(x, y, yhat, Mask)
    x = x - gard * stepsize
    return x

def init_logger(argdict):
	r"""Initializes a logging.Logger to save all the running parameters to a
	log file

	Args:
		argdict: dictionary of parameters to be logged
	"""
	from os.path import join
	logger = logging.getLogger(__name__)
	logger.setLevel(level=logging.INFO)
	fh = logging.FileHandler(join(argdict.log_dir, 'log.txt'), mode='a')
	formatter = logging.Formatter('%(asctime)s - %(message)s')
	fh.setFormatter(formatter)
	logger.addHandler(fh)
	# try:
	# 	logger.info("Commit: {}".format(get_git_revision_short_hash()))
	# except Exception as e:
	# 	logger.error("Couldn't get commit number: {}".format(e))
	logger.info("Arguments: ")
	for k in argdict.__dict__:
		logger.info("\t{}: {}".format(k, argdict.__dict__[k]))

	return logger
#######################################################################################################################

##------------------------------    epsilon-learn------------------------------------------
class DeepDI_CSCnet_Onelayer_learn(nn.Module):
    def __init__(self, params):
        super(DeepDI_CSCnet_Onelayer_learn, self).__init__()
        self.CSCmodel = ConvLista_T_learning(params).cuda()
        self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
    def forward(self, y, z_batch, Mask, gamma, iteration):
        z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
        x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
        z_batch = Aproj_CPR_torch_cuda(x_batch,4, y, Mask, torch.abs(self.beta)).cuda()
        return x_batch, z_batch, gamma

# ##------------------------------ epsilon-net/updating-------------------------------------
# class DeepDI_CSCnet_Onelayer_updating(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_updating, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_updating(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ attention residual-------------------------------------
# class DeepDI_CSCnet_Onelayer_attention_residual(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention_residual, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention_residual(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
##------------------------------ attention1-------------------------------------
###beta=0.5/1
class DeepDI_CSCnet_Onelayer_attention1(nn.Module):
    def __init__(self, params):
        super(DeepDI_CSCnet_Onelayer_attention1, self).__init__()
        # self.CSCmodel = ConvLista_T_learning(params).cuda()
        self.CSCmodel = ConvLista_T_attention1(params).cuda()
        self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
    def forward(self, y, z_batch, Mask, gamma, iteration):
        z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
        x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
        z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
        return x_batch, z_batch, gamma
###beta=0
class DeepDI_CSCnet_Onelayer_attention1_nobeta(nn.Module):
    def __init__(self, params):
        super(DeepDI_CSCnet_Onelayer_attention1_nobeta, self).__init__()
        self.CSCmodel = ConvLista_T_attention1(params).cuda()
    def forward(self, y, z_batch, Mask, gamma, iteration):
        z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
        x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
        z_batch = Aproj_CPR_torch_cuda_nobeta(x_batch, 4, y, Mask).cuda()
        return x_batch, z_batch, gamma

class DeepDI_CSCnet_Onelayer_iteration(nn.Module):
    def __init__(self, params):
        super(DeepDI_CSCnet_Onelayer_iteration, self).__init__()
        self.CSCmodel = ConvLista_T_iteration(params).cuda()
        self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
    def forward(self, y, z_batch, Mask, gamma, iteration):
        z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
        x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
        z_batch = Aproj_CPR_torch_cuda_nobeta(x_batch, 4, y, Mask).cuda()
        return x_batch, z_batch, gamma
##------------------------------ attention1_gardient_descent-------------------------------------
class DeepDI_CSCnet_Onelayer_attention1_grad(nn.Module):
    def __init__(self, params):
        super(DeepDI_CSCnet_Onelayer_attention1_grad, self).__init__()
        self.CSCmodel = ConvLista_T_attention1(params).cuda()
        self.step_size = nn.Parameter(torch.FloatTensor([params.step_size]), requires_grad=True)
    def forward(self, y, z_batch, Mask, gamma, iteration):
        z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
        x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
        z_batch = updating_image_torch_cuda(x_batch,4, y, Mask, self.step_size).cuda()
        return x_batch, z_batch, gamma

##------------------------------ attention1_gardient_descent_add-------------------------------------
class DeepDI_CSCnet_Onelayer_attention1_grad_add(nn.Module):
    def __init__(self, params):
        super(DeepDI_CSCnet_Onelayer_attention1_grad_add, self).__init__()
        self.CSCmodel = ConvLista_T_attention1_grad_add(params).cuda()
        self.step_size = nn.Parameter(torch.FloatTensor([params.step_size]), requires_grad=True)
    def forward(self, y, z_batch, Mask, gamma, iteration):
        z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
        x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
        z_batch = updating_image_torch_cuda(x_batch,4, y, Mask, self.step_size).cuda()
        return x_batch, z_batch, gamma

class DeepDI_CSCnet_Onelayer_attention2_10_5_00001001(nn.Module):
    def __init__(self, params):
        super(DeepDI_CSCnet_Onelayer_attention2_10_5_00001001, self).__init__()
        self.CSCmodel = ConvLista_T_attention2_grad_10_5_00001001(params).cuda()
        self.step_size = nn.Parameter(torch.FloatTensor([params.step_size]), requires_grad=True)
    def forward(self, y, z_batch, Mask, gamma, iteration):
        z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
        x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
        z_batch = updating_image_torch_cuda(x_batch,4, y, Mask, self.step_size).cuda()
        return x_batch, z_batch, gamma
# ##------------------------------ attention1 Add-------------------------------------
# class DeepDI_CSCnet_Onelayer_attention1_Add(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention1_Add, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention1_Add(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ attention1 reduce-------------------------------------
# class DeepDI_CSCnet_Onelayer_attention1_reduce(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention1_reduce, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention1_reduce(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ attention3-------------------------------------
# class DeepDI_CSCnet_Onelayer_attention3(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention3, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention3(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ attention residual2-------------------------------------
# class DeepDI_CSCnet_Onelayer_attention_residual2(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention_residual2, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention_residual2(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ attention residual2 add-------------------------------------
# class DeepDI_CSCnet_Onelayer_attention_residual2_add(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention_residual2_add, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention_residual2_add(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ attention dense-------------------------------------
# class DeepDI_CSCnet_Onelayer_attention_dense(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention_dense, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention_dense(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ attention dense residual-------------------------------------
# class DeepDI_CSCnet_Onelayer_attention_dense_residual(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention_dense_residual, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention_dense_residual(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ feature attention residual Multi---------------------------------
# class DeepDI_CSCnet_Onelayer_attention_residual_Multi(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention_residual_Multi, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention_residual_Multi(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ feature attention residual Multi residual---------------------------------
# class DeepDI_CSCnet_Onelayer_attention_residual_Multi_residual(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention_residual_Multi_residual, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention_residual_Multi_residual(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ feature attention residual Multi 2---------------------------------
# class DeepDI_CSCnet_Onelayer_attention_residual_Multi_residual2(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention_residual_Multi_residual2, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention_residual_Multi_residual2(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ feature attention residual Multi two---------------------------------
# class DeepDI_CSCnet_Onelayer_attention_residual_Multi_two(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_attention_residual_Multi_two, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_attention_residual_Multi_two(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
#
# ##------------------------------ M_RSAN---------------------------------
# class DeepDI_CSCnet_Onelayer_Multi_scale_attention(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_Multi_scale_attention, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_Multi_scale_attention(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
#
# ##------------------------------ M_RSAN_shared---------------------------------
# class DeepDI_CSCnet_Onelayer_Multi_scale_attention_shared(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_Multi_scale_attention_shared, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_Multi_scale_attention_shared(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
#
# ##------------------------------ Dual branch Prior residual---------------------------------
# class DeepDI_CSCnet_Onelayer_Dual_branch_Prior_residual(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_Dual_branch_Prior_residual, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_Dual_branch_Prior_residual(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ Dual branch Prior residual2---------------------------------
# class DeepDI_CSCnet_Onelayer_Dual_branch_Prior_residual2(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_Dual_branch_Prior_residual2, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_Dual_branch_Prior_residual2(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ Dual branch Prior residual single---------------------------------
# class DeepDI_CSCnet_Onelayer_Dual_branch_Prior_residual_single(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_Dual_branch_Prior_residual_single, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_Dual_branch_Prior_residual_single(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ Dual Multi Prior residual---------------------------------
# class DeepDI_CSCnet_Onelayer_Dual_Multi_Prior_residual(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_Dual_Multi_Prior_residual, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_Dual_Multi_Prior_residual(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ Multi scale local attention---------------------------------
# class DeepDI_CSCnet_Onelayer_Multi_scale_local_attention(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_Multi_scale_local_attention, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_Multi_scale_local_attention(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ Multi scale local attention---------------------------------
# class DeepDI_CSCnet_Onelayer_Multi_scale_local_attention_enhance(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_Multi_scale_local_attention_enhance, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_Multi_scale_local_attention_enhance(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
# ##------------------------------ Image_and_Coefficient---------------------------------
# class DeepDI_CSCnet_Onelayer_Image_and_Coefficient(nn.Module):
#     def __init__(self, params):
#         super(DeepDI_CSCnet_Onelayer_Image_and_Coefficient, self).__init__()
#         # self.CSCmodel = ConvLista_T_learning(params).cuda()
#         self.CSCmodel = ConvLista_T_Image_and_Coefficient(params).cuda()
#         self.beta = nn.Parameter(torch.FloatTensor([params.beta]), requires_grad=True)
#     def forward(self, y, z_batch, Mask, gamma, iteration):
#         z_batch = torch.clamp(z_batch, 0., 1.)###将z_batch归一化到0-1；
#         x_batch, gamma = self.CSCmodel(z_batch, gamma, iteration)
#         z_batch = Aproj_CPR_torch_cuda(x_batch, 4, y, Mask, torch.abs(self.beta)).cuda()
#         return x_batch, z_batch, gamma
#######################################################################################################################
##------------------------------    epsilon-learn-----------------------------------------------

class DeepDI_CSCnet_learn(nn.Module):
    def __init__(self, layers_num=20,  unfoldings=8):
        super(DeepDI_CSCnet_learn, self).__init__()
        self.depth = layers_num
        layers = []
        kernel_size = 13
        num_filters = 200
        stride = 5
        epsilon = 0.01
        beta = 0.7
        params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
        for _ in range(self.depth):
            single_layer = DeepDI_CSCnet_Onelayer_learn(params)
            layers.append(single_layer)
        self.net = nn.Sequential(*layers)
    def forward(self, y, x0, Mask):
## inout:
#    y one noise CDP
#    x0  the estimated image
#    Mask the mask for modulation
        x = x0
        z = x0
        gamma = 0
        for i in range(self.depth):
            x, z, gamma = self.net[i](y, z, Mask, gamma, i)
        return x

# ##------------------------------ epsilon-net/updating--------------------------------------------
# class DeepDI_CSCnet_updating(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_updating, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_updating(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
#
# ##-----------------------------feature attention residual------------------------------------------
# class DeepDI_CSCnet_attention_residual(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention_residual, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention_residual(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
##-----------------------------feature attention residual1------------------------------------------
### beta=1/0.5
class DeepDI_CSCnet_attention1(nn.Module):
    def __init__(self, layers_num=20,  unfoldings=8):
        super(DeepDI_CSCnet_attention1, self).__init__()
        self.depth = layers_num
        layers = []
        kernel_size = 13
        num_filters = 200
        stride = 5
        epsilon = 0.01
        beta = 0.7
        params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
        for _ in range(self.depth):
            single_layer = DeepDI_CSCnet_Onelayer_attention1(params)
            layers.append(single_layer)
        self.net = nn.Sequential(*layers)
    def forward(self, y, x0, Mask):
## inout:
#    y one noise CDP
#    x0  the estimated image
#    Mask the mask for modulation
        x = x0
        z = x0
        gamma = 0
        for i in range(self.depth):
            x, z, gamma = self.net[i](y, z, Mask, gamma, i)
        return x
### beta=0
class DeepDI_CSCnet_attention1_nobeta(nn.Module):
    def __init__(self, layers_num=20,  unfoldings=8):
        super(DeepDI_CSCnet_attention1_nobeta, self).__init__()
        self.depth = layers_num
        layers = []
        kernel_size = 13
        num_filters = 200
        stride = 5
        epsilon = 0.01
        params = ListaParams_nobeta(kernel_size, num_filters, stride, unfoldings, epsilon)
        for _ in range(self.depth):
            single_layer = DeepDI_CSCnet_Onelayer_attention1_nobeta(params)
            layers.append(single_layer)
        self.net = nn.Sequential(*layers)
    def forward(self, y, x0, Mask):
## inout:
#    y one noise CDP
#    x0  the estimated image
#    Mask the mask for modulation
        x = x0
        z = x0
        gamma = 0
        for i in range(self.depth):
            x, z, gamma = self.net[i](y, z, Mask, gamma, i)
        return x
#### threshold updating via iteration
class DeepDI_CSCnet_iteration(nn.Module):
    def __init__(self, layers_num=20,  unfoldings=8):
        super(DeepDI_CSCnet_iteration, self).__init__()
        self.depth = layers_num
        layers = []
        kernel_size = 13
        num_filters = 200
        stride = 5
        tau=0.01
        epsilon = 0.01
        beta = 0.7
        params = ListaParams_iteration(kernel_size, num_filters, stride, unfoldings, beta, tau, epsilon)
        for _ in range(self.depth):
            single_layer = DeepDI_CSCnet_Onelayer_iteration(params)
            layers.append(single_layer)
        self.net = nn.Sequential(*layers)
    def forward(self, y, x0, Mask):
## inout:
#    y one noise CDP
#    x0  the estimated image
#    Mask the mask for modulation
        x = x0
        z = x0
        gamma = 0
        for i in range(self.depth):
            x, z, gamma = self.net[i](y, z, Mask, gamma, i)
        return x
### beta=0
##-----------------------------attention1_15dB_grad------------------------------------------
class DeepDI_CSCnet_attention1_grad(nn.Module):
    def __init__(self, layers_num=8,  unfoldings=20):
        super(DeepDI_CSCnet_attention1_grad, self).__init__()
        self.depth = layers_num
        layers = []
        kernel_size = 13
        num_filters = 200
        stride = 5
        epsilon = 0.01
        # beta = 0.5
        step_size = 0.01
        params = ListaParams_grad(kernel_size, num_filters, stride, unfoldings,epsilon,step_size)
        for _ in range(self.depth):
            single_layer = DeepDI_CSCnet_Onelayer_attention1_grad(params)
            layers.append(single_layer)
        self.net = nn.Sequential(*layers)
    def forward(self, y, x0, Mask):
## inout:
#    y one noise CDP
#    x0  the estimated image
#    Mask the mask for modulation
        x = x0
        z = x0
        gamma = 0
        for i in range(self.depth):
            x, z, gamma = self.net[i](y, z, Mask, gamma, i)
        return x

##-----------------------------attention1_15dB_grad_add------------------------------------------
class DeepDI_CSCnet_attention1_grad_add(nn.Module):
    def __init__(self, layers_num=8,  unfoldings=20):
        super(DeepDI_CSCnet_attention1_grad_add, self).__init__()
        self.depth = layers_num
        layers = []
        kernel_size = 13
        num_filters = 200
        stride = 5
        epsilon = 0.01
        step_size = 0.01
        params = ListaParams_grad(kernel_size, num_filters, stride, unfoldings,epsilon,step_size)
        for _ in range(self.depth):
            single_layer = DeepDI_CSCnet_Onelayer_attention1_grad_add(params)
            layers.append(single_layer)
        self.net = nn.Sequential(*layers)
    def forward(self, y, x0, Mask):
## inout:
#    y one noise CDP
#    x0  the estimated image
#    Mask the mask for modulation
        x = x0
        z = x0
        gamma = 0
        for i in range(self.depth):
            x, z, gamma = self.net[i](y, z, Mask, gamma, i)
        return x


##-----------------------------attention1_15dB_grad_add-00001002------------------------------------------
class DeepDI_CSCnet_attention1_grad_add_00001002(nn.Module):
    def __init__(self, layers_num=8,  unfoldings=20):
        super(DeepDI_CSCnet_attention1_grad_add_00001002, self).__init__()
        self.depth = layers_num
        layers = []
        kernel_size = 13
        num_filters = 200
        stride = 5
        epsilon = 0.01
        step_size = 0.01
        params = ListaParams_grad(kernel_size, num_filters, stride, unfoldings,epsilon,step_size)
        for _ in range(self.depth):
            single_layer = DeepDI_CSCnet_Onelayer_attention1_grad_add(params)
            layers.append(single_layer)
        self.net = nn.Sequential(*layers)
    def forward(self, y, x0, Mask):
## inout:
#    y one noise CDP
#    x0  the estimated image
#    Mask the mask for modulation
        x = x0
        z = x0
        gamma = 0
        for i in range(self.depth):
            x, z, gamma = self.net[i](y, z, Mask, gamma, i)
        return x
##-----------------------------attention1_15dB_grad_add-000010005------------------------------------------
class DeepDI_CSCnet_attention1_grad_add_000010005(nn.Module):
    def __init__(self, layers_num=10,  unfoldings=5):
        super(DeepDI_CSCnet_attention1_grad_add_000010005, self).__init__()
        self.depth = layers_num
        layers = []
        kernel_size = 13
        num_filters = 200
        stride = 5
        epsilon = 0.01
        step_size = 0.005
        params = ListaParams_grad(kernel_size, num_filters, stride, unfoldings,epsilon,step_size)
        for _ in range(self.depth):
            single_layer = DeepDI_CSCnet_Onelayer_attention1_grad_add(params)
            layers.append(single_layer)
        self.net = nn.Sequential(*layers)
    def forward(self, y, x0, Mask):
## inout:
#    y one noise CDP
#    x0  the estimated image
#    Mask the mask for modulation
        x = x0
        z = x0
        gamma = 0
        for i in range(self.depth):
            x, z, gamma = self.net[i](y, z, Mask, gamma, i)
        return x

##-----------------------------attention2_15dB-----------------------------------------
class DeepDI_CSCnet_attention2_10_5_00001001(nn.Module):
    def __init__(self, layers_num=8,  unfoldings=20):
        super(DeepDI_CSCnet_attention2_10_5_00001001, self).__init__()
        self.depth = layers_num
        layers = []
        kernel_size = 13
        num_filters = 200
        stride = 5
        epsilon = 0.01
        step_size = 0.01
        params = ListaParams_grad(kernel_size, num_filters, stride, unfoldings,epsilon,step_size)
        for _ in range(self.depth):
            single_layer = DeepDI_CSCnet_Onelayer_attention2_10_5_00001001(params)
            layers.append(single_layer)
        self.net = nn.Sequential(*layers)
    def forward(self, y, x0, Mask):
## inout:
#    y one noise CDP
#    x0  the estimated image
#    Mask the mask for modulation
        x = x0
        z = x0
        gamma = 0
        for i in range(self.depth):
            x, z, gamma = self.net[i](y, z, Mask, gamma, i)
        return x
# ##-----------------------------feature attention residual1_Add------------------------------------------
# class DeepDI_CSCnet_attention1_Add(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention1_Add, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention1_Add(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention residual1_Add------------------------------------------
# class DeepDI_CSCnet_attention1_reduce(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention1_reduce, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention1_reduce(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention residual3------------------------------------------
# class DeepDI_CSCnet_attention3(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention3, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention3(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention residual2------------------------------------------
# class DeepDI_CSCnet_attention_residual2(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention_residual2, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention_residual2(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention residual2 add------------------------------------------
# class DeepDI_CSCnet_attention_residual2_add(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention_residual2_add, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention_residual2_add(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention dense------------------------------------------
# class DeepDI_CSCnet_attention_dense(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention_dense, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention_dense(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention dense residual------------------------------------------
# class DeepDI_CSCnet_attention_dense_residual(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention_dense_residual, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention_dense_residual(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention residual Multi------------------------------------------
# class DeepDI_CSCnet_attention_residual_Multi(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention_residual_Multi, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention_residual_Multi(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention residual Multi residual------------------------------------------
# class DeepDI_CSCnet_attention_residual_Multi_residual(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention_residual_Multi_residual, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention_residual_Multi_residual(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention residual Multi residual------------------------------------------
# class DeepDI_CSCnet_attention_residual_Multi_residual2(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention_residual_Multi_residual2, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention_residual_Multi_residual2(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------feature attention residual Multi two------------------------------------------
# class DeepDI_CSCnet_attention_residual_Multi_two(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_attention_residual_Multi_two, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_attention_residual_Multi_two(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
#
# ##-----------------------------M_RSAN------------------------------------------
# class DeepDI_CSCnet_Multi_scale_attention(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_Multi_scale_attention, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_Multi_scale_attention(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------M_RSAN_shared------------------------------------------
# class DeepDI_CSCnet_Multi_scale_attention_shared(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_Multi_scale_attention_shared, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_Multi_scale_attention_shared(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
#
# ##-----------------------------Dual branch Prior Residual ------------------------------------------
# class DeepDI_CSCnet_Dual_branch_Prior_residual(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_Dual_branch_Prior_residual, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_Dual_branch_Prior_residual(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------Dual branch Fusion residual2 ------------------------------------------
# class DeepDI_CSCnet_Dual_branch_Prior_residual2(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_Dual_branch_Prior_residual2, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_Dual_branch_Prior_residual2(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------Dual branch Fusion residual2 ------------------------------------------
# class DeepDI_CSCnet_Dual_branch_Prior_residual_single(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_Dual_branch_Prior_residual_single, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_Dual_branch_Prior_residual_single(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##-----------------------------Dual Multi Prior residual ------------------------------------------
# class DeepDI_CSCnet_Dual_Multi_Prior_residual(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_Dual_Multi_Prior_residual, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_Dual_Multi_Prior_residual(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##----------------------------Multi scale local attention  ------------------------------------------
# class DeepDI_CSCnet_Multi_scale_local_attention(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_Multi_scale_local_attention, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_Multi_scale_local_attention(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##----------------------------Multi scale local attention enhance ------------------------------------------
# class DeepDI_CSCnet_Multi_scale_local_attention_enhance(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_Multi_scale_local_attention_enhance, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_Multi_scale_local_attention_enhance(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
# ##----------------------------Image_and_Coefficient ------------------------------------------
# class DeepDI_CSCnet_Image_and_Coefficient(nn.Module):
#     def __init__(self, layers_num=20,  unfoldings=8):
#         super(DeepDI_CSCnet_Image_and_Coefficient, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 13
#         num_filters = 200
#         stride = 5
#         epsilon = 0.01
#         beta = 0.5
#         params = ListaParams(kernel_size, num_filters, stride, unfoldings, beta, epsilon)
#         for _ in range(self.depth):
#             single_layer = DeepDI_CSCnet_Onelayer_Image_and_Coefficient(params)
#             layers.append(single_layer)
#         self.net = nn.Sequential(*layers)
#     def forward(self, y, x0, Mask):
# ## inout:
# #    y one noise CDP
# #    x0  the estimated image
# #    Mask the mask for modulation
#         x = x0
#         z = x0
#         gamma = 0
#         for i in range(self.depth):
#             x, z, gamma = self.net[i](y, z, Mask, gamma, i)
#         return x
