from __future__ import print_function
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0'##
import torch
torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark =True
dtype = torch.cuda.FloatTensor
from PRpytorch_function import *
import dataloaders
import time
import numpy as np
import argparse
import matplotlib.pyplot as plt
from skimage.measure import compare_ssim
dtype = torch.cuda.FloatTensor
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
device_ids = [0]
torch.cuda.set_device(0)
parser = argparse.ArgumentParser()
parser.add_argument("--model_PRNet_dir", type=str, dest="root_folder_PRNet", help="The trained model's dir path", default='PRNet/PRNet_25dB')
parser.add_argument("--model_PRNet_name", type=str, dest="uuid_PRNet", help="The model's name", default= 'PRNet_25dB')

parser.add_argument("--data_path", type=str, dest="data_path", help="Path to the dir containing the training and testing datasets.", default="Gyt/PRNet/Data")
args = parser.parse_args()


config_filename_PRNet = args.uuid_PRNet+'.config'
model_filename_PRNet= args.uuid_PRNet+'.model'
config_path_PRNet = join(args.root_folder_PRNet, config_filename_PRNet)
with open(config_path_PRNet) as conf_file_PRNet:
    conf_PRNet = conf_file_PRNet.read()
conf_PRNet = eval(conf_PRNet)
model_PRNet = DeepDI_CSCnet_attention1(layers_num=8, unfoldings=5).cuda()# 8  5 #①
model_PRNet = nn.DataParallel(model_PRNet).cuda()
model_PRNet.load_state_dict(torch.load(join(args.root_folder_PRNet, model_filename_PRNet)))

test_path = [f'{args.data_path}/cell8']#####  the dataset
loaders = dataloaders.get_dataloaders2(test_path, 1)
loaders['test'].dataset.verbose = True

model_PRNet.eval()   # Set model to evaluate mode #③
model_PRNet.cuda()

num_iters = 0
totaltime = 0
psnr= 0
ssim = 0
SNR = 25  ##modify the SNR value

for batch, imagename in loaders['test']:
    Mask = np.random.choice([1, -1, complex('-j'), complex('j')],size=(batch.shape)).astype('complex128')
    Mask_real = np.real(Mask)
    Mask_imag = np.imag(Mask)
    Mask_torch = torch.cat((torch.FloatTensor(Mask_real), torch.FloatTensor(Mask_imag)), 1)
    batch, Mask_torch = Variable(batch.cuda()), Variable(Mask_torch.cuda())
    yy = Sampling_torch_cuda(batch, Mask_torch)
    yy_abs = magnitude(yy)
    y_batch = yy_abs.mul(yy_abs)
    ynoise_batch = y_batch + wgn_torch_cuda(y_batch, SNR)
    x0 = torch.randn(batch.shape)
    x0, ynoise_batch = Variable(x0.cuda()), Variable(ynoise_batch.cuda())
    with torch.no_grad():  # this can save much memory
        time_start = time.time()
        output = model_PRNet(ynoise_batch, x0, Mask_torch)
        time_end = time.time()
        loss = (output - batch).pow(2).sum() / batch.shape[0]
        cur_psnr = -10 * np.log10(loss.item() / (batch.shape[2] * batch.shape[3]))
        Image = (output.cpu()).numpy()
        Imin = (batch.cpu()).numpy()
        cur_ssim = compare_ssim(np.squeeze(Image), np.squeeze(Imin))
        cur_time = time_end - time_start

        totaltime += cur_time
        psnr += cur_psnr
        ssim += cur_ssim
        print(f'PRNet-TIME-{imagename[0]}:\t{cur_time}')
        print(f'PRNet-PSNR-{imagename[0]}:\t{cur_psnr}')
        print(f'PRNet-SSIM-{imagename[0]}:\t{cur_ssim}')

        num_iters += 1
print('===========================')
print(f'PRNet-TIME-Average:\t{totaltime / num_iters}')
print(f'PRNet-PSNR-Average:\t{psnr / num_iters}')
print(f'PRNet-SSIM-Average:\t{ssim / num_iters}')