import torch
import numpy as np
from torch import nn
from torch.nn import functional
from collections import namedtuple
from utils import conv_power_method, calc_pad_sizes
import math
import torch.nn.functional as F
import CA_model_v2
import sys
sys.path.append('/home/walker/Documents/GYT/DeepCSCPR/Function')
from merge_unit import *

class Threshold_net(nn.Module):
    def __init__(self,channels, layers_num=4):
        super(Threshold_net, self).__init__()
        layers = []
        self.depth = layers_num
        kernel_size = 3  ### 卷积核大小
        padding = 1  # 填充
        features = 200  ### feature map的数量
        for _ in range(self.depth - 1):
            layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
            layers.append(nn.ReLU(inplace=True))  ## Relu
        layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
        self.epsilon_net = nn.Sequential(*layers)
    def forward(self, x):
        epsilon = self.epsilon_net(x)
        return epsilon

class Threshold_net_attention2(nn.Module):
    def __init__(self,channels, layers_num=4):
        super(Threshold_net_attention2, self).__init__()
        layers = []
        self.depth = layers_num
        kernel_size = 3  ### 卷积核大小
        padding = 1  # 填充
        features = 200  ### feature map的数量
        layers.append(RCAB(channel=channels))
        layers.append(RCAB(channel=channels))
        for _ in range(self.depth - 1):
            layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
            layers.append(nn.ReLU(inplace=True))  ## Relu
        layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
        self.epsilon_net = nn.Sequential(*layers)
    def forward(self, x):
        epsilon = self.epsilon_net(x)
        return epsilon
class Threshold_net_attention1(nn.Module):
    def __init__(self,channels, layers_num=4):
        super(Threshold_net_attention1, self).__init__()
        layers = []
        self.depth = layers_num
        kernel_size = 3  ### 卷积核大小
        padding = 1  # 填充
        features = 200  ### feature map的数量
        layers.append(RCAB(channel=channels))
        for _ in range(self.depth - 1):
            layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
            layers.append(nn.ReLU(inplace=True))  ## Relu
        layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
        self.epsilon_net = nn.Sequential(*layers)
    def forward(self, x):
        epsilon = self.epsilon_net(x)
        return epsilon
# class Threshold_net_attention1_Add(nn.Module):
#     def __init__(self,channels, layers_num=5):
#         super(Threshold_net_attention1_Add, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         layers.append(RCAB(channel=channels))
#         for _ in range(self.depth - 1):
#             layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
#             layers.append(nn.ReLU(inplace=True))  ## Relu
#         layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class Threshold_net_attention1_reduce(nn.Module):
#     def __init__(self,channels, layers_num=3):
#         super(Threshold_net_attention1_reduce, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         layers.append(RCAB(channel=channels))
#         for _ in range(self.depth - 1):
#             layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
#             layers.append(nn.ReLU(inplace=True))  ## Relu
#         layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
class Threshold_net_attention3(nn.Module):
    def __init__(self,channels, layers_num=4):
        super(Threshold_net_attention3, self).__init__()
        layers = []
        self.depth = layers_num
        kernel_size = 3  ### 卷积核大小
        padding = 1  # 填充
        features = 200  ### feature map的数量
        layers.append(RCAB(channel=channels))
        layers.append(RCAB(channel=channels))
        layers.append(RCAB(channel=channels))
        for _ in range(self.depth - 1):
            layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
            layers.append(nn.ReLU(inplace=True))  ## Relu
        layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
        self.epsilon_net = nn.Sequential(*layers)
    def forward(self, x):
        epsilon = self.epsilon_net(x)
        return epsilon
# class Threshold_net_attention_residual2(nn.Module):
#     def __init__(self,channels, layers_num=4):
#         super(Threshold_net_attention_residual2, self).__init__()
#         layers = []
#         CNNs = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         layers.append(RCAB(channel=channels))
#         layers.append(RCAB(channel=channels))
#         CNNs.append(nn.Sequential(
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False),
#         ))
#         self.RCAB = nn.Sequential(*layers)
#         self.CNNs = nn.Sequential(*CNNs)
#         self.Conv = nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False)
#         self.relu =  nn.ReLU(inplace=True)
#     def forward(self, x):
#         feature = self.RCAB(x)
#         temp = feature
#         output1 = self.CNNs(feature)
#         output2 = temp + output1
#         output = self.relu(output2)
#         return output
# class Threshold_net_attention_residual2_add(nn.Module):
#     def __init__(self,channels):
#         super(Threshold_net_attention_residual2_add, self).__init__()
#         layers = []
#         CNNs = []
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         layers.append(RCAB(channel=channels))
#         layers.append(RCAB(channel=channels))
#         CNNs.append(nn.Sequential(
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False),
#                 nn.ReLU(inplace=True),
#                 nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False)
#         ))
#         self.RCAB = nn.Sequential(*layers)
#         self.CNNs = nn.Sequential(*CNNs)
#         self.Conv = nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False)
#         self.relu =  nn.ReLU(inplace=True)
#     def forward(self, x):
#         feature = self.RCAB(x)
#         temp = feature
#         output1 = self.CNNs(feature)
#         output2 = temp + output1
#         output = self.relu(output2)
#         return output
# ##########dense connected
# def conv_block(in_channels,outchannels):
#     blk = nn.Sequential(nn.Conv2d(in_channels,outchannels,kernel_size=3,padding=1),
#                         nn.ReLU()
#                        )
#     return  blk
# class DenseBlock(nn.Module):
#     def __init__(self, num_convs, in_channels, out_channels):
#         super(DenseBlock, self).__init__()
#         net = []
#         for i in range(num_convs):
#             in_c = in_channels + i * out_channels
#             net.append((conv_block(in_c,out_channels)))
#         self.net = nn.ModuleList(net)
#         out_c = in_channels + num_convs * out_channels
#         self.relu = nn.ReLU()
#         self.conv1 = nn.Conv2d(out_c,out_channels,kernel_size=1,padding=0)
#
#     def forward(self,X):
#         temp = X
#         for blk in self.net:
#             Y = blk(temp)
#             temp = torch.cat((temp,Y),dim =1)
#         temp1 = self.conv1(temp)
#         # temp2 = X + temp1
#         epsilon = self.relu(temp1)
#         return epsilon
# class Threshold_net_attention_dense(nn.Module):
#     def __init__(self,channels, num_convs=4):
#         super(Threshold_net_attention_dense, self).__init__()
#         layers = []
#         layers.append(RCAB(channel=channels))
#         layers.append(RCAB(channel=channels))
#         layers.append(DenseBlock(num_convs,in_channels=channels,out_channels=channels))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# #########dense residual
# class DenseBlock_residual(nn.Module):
#     def __init__(self, num_convs, in_channels, out_channels):
#         super(DenseBlock_residual, self).__init__()
#         net = []
#         for i in range(num_convs):
#             in_c = in_channels + i * out_channels
#             net.append((conv_block(in_c,out_channels)))
#         self.net = nn.ModuleList(net)
#         out_c = in_channels + num_convs * out_channels
#         self.relu = nn.ReLU()
#         self.conv1 = nn.Conv2d(out_c,out_channels,kernel_size=1,padding=0)
#     def forward(self,X):
#         temp = X
#         for blk in self.net:
#             Y = blk(temp)
#             temp = torch.cat((temp,Y),dim =1)
#         temp1 = self.conv1(temp)
#         temp2 = X + temp1
#         epsilon = self.relu(temp2)
#         return epsilon
# class Threshold_net_attention_dense_residual(nn.Module):
#     def __init__(self,channels, num_convs=4):
#         super(Threshold_net_attention_dense_residual, self).__init__()
#         layers = []
#         layers.append(RCAB(channel=channels))
#         layers.append(RCAB(channel=channels))
#         layers.append(DenseBlock_residual(num_convs,in_channels=channels,out_channels=channels))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# #########attention_Multi
# class Threshold_net_attention_residual_Multi(nn.Module):
#     def __init__(self,channels, layers_num=4):
#         super(Threshold_net_attention_residual_Multi, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         layers.append(M_RCAB(channel=channels))
#         for _ in range(self.depth - 1):
#             layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
#             layers.append(nn.ReLU(inplace=True))  ## Relu
#         layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class Threshold_net_attention_residual_Multi_residual(nn.Module):
#     def __init__(self,channels, layers_num=4):
#         super(Threshold_net_attention_residual_Multi_residual, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         layers.append(M_RCAB(channel=channels))
#         for _ in range(self.depth - 1):
#             layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
#             layers.append(nn.ReLU(inplace=True))  ## Relu
#         layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class Threshold_net_attention_residual_Multi_residual2(nn.Module):
#     def __init__(self,channels, layers_num=4):
#         super(Threshold_net_attention_residual_Multi_residual2, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         layers.append(M_RCAB2(channel=channels))
#         for _ in range(self.depth - 2):
#             layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
#             layers.append(nn.ReLU(inplace=True))  ## Relu
#         layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class Threshold_net_attention_residual_Multi_two(nn.Module):
#     def __init__(self,channels, layers_num=4):
#         super(Threshold_net_attention_residual_Multi_two, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         layers.append(M_RSAB_shared(channel=channels))
#         for _ in range(self.depth - 1):
#             layers.append( nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
#             layers.append(nn.ReLU(inplace=True))  ## Relu
#         layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon

## class Feature_Prior(nn.Module):
#     def __init__(self, channels):
#         super(Feature_Prior, self).__init__()
#         layers=[]
#         layers.append(RCAB(channel=channels))
#         layers.append(RCAB(channel=channels))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class Deep_Prior(nn.Module):
#     def __init__(self, channels,layers_num=4):
#         super(Deep_Prior, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         for _ in range(self.depth - 1):
#             layers.append(nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
#             layers.append(nn.ReLU(inplace=True))  ## Relu
#         layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding,bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class Deep_Prior5(nn.Module):
#     def __init__(self, channels,layers_num=4):
#         super(Deep_Prior5, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 5  ### 卷积核大小
#         padding = kernel_size//2  # 填充
#         features = 200  ### feature map的数量
#         for _ in range(self.depth - 1):
#             layers.append(nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
#             layers.append(nn.ReLU(inplace=True))  ## Relu
#         layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding,bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class Threshold_Dual_branch_Prior(nn.Module):
#     def __init__(self, in_channels, out_channels, vector_length, layers_num):
#         super(Threshold_Dual_branch_Prior, self).__init__()
#         self.Conv = nn.Conv2d(in_channels=in_channels,out_channels=in_channels,kernel_size=3, padding=1,bias=False)
#         self.Feature_Prior = Feature_Prior(channels=in_channels)
#         self.Deep_Prior = Deep_Prior(channels=in_channels,layers_num=layers_num)
#         self.fc = nn.Linear(in_features=in_channels,out_features=vector_length)
#         self.att_FP = nn.Linear(in_features=vector_length,out_features=out_channels)
#         self.att_DP = nn.Linear(in_features=vector_length, out_features=out_channels)
#         self.softmax = nn.Softmax(dim=1)
#     def forward(self, x):
#         input = self.Conv(x)
#         out1 = self.Feature_Prior(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#         out2 = self.Deep_Prior(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#
#         out = torch.cat((out2, out1), dim=1)  ## 1：按行拼接(行数增加)；0：按列拼接（列数增加） (25,2,200,26,26)
#         add_wise = torch.sum(out, dim=1)  ## 1：横向压缩，将每一行的元素进行相加；0：纵向压缩，将每一列的元素进行相加
#         gb_vector = add_wise.mean(-1).mean(-1)
#         gb_vector = self.fc(gb_vector)
#         gb_vector_FP = self.att_FP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         gb_vector_DP = self.att_DP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         vector = torch.cat((gb_vector_FP, gb_vector_DP), dim=1)
#         vector = self.softmax(vector).unsqueeze(-1).unsqueeze(-1)
#         out = (out * vector).sum(dim=1)
#
#         # out = out + x
#         return out
# class Threshold_Dual_branch_Prior_residual(nn.Module):
#     def __init__(self, in_channels, out_channels, vector_length, layers_num):
#         super(Threshold_Dual_branch_Prior_residual, self).__init__()
#         self.Conv = nn.Conv2d(in_channels=in_channels,out_channels=in_channels,kernel_size=3, padding=1,bias=False)
#         self.Feature_Prior = Feature_Prior(channels=in_channels)
#         self.Deep_Prior = Deep_Prior(channels=in_channels,layers_num=layers_num)
#         self.fc = nn.Linear(in_features=in_channels,out_features=vector_length)
#         self.att_FP = nn.Linear(in_features=vector_length,out_features=out_channels)
#         self.att_DP = nn.Linear(in_features=vector_length, out_features=out_channels)
#         self.softmax = nn.Softmax(dim=1)
#         self.relu = nn.ReLU(inplace=True)
#     def forward(self, x):
#         input = self.Conv(x)
#         out1 = self.Feature_Prior(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#         out2 = self.Deep_Prior(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#
#         out = torch.cat((out2, out1), dim=1)  ## 1：按行拼接(行数增加)；0：按列拼接（列数增加） (25,2,200,26,26)
#         add_wise = torch.sum(out, dim=1)  ## 1：横向压缩，将每一行的元素进行相加；0：纵向压缩，将每一列的元素进行相加
#         gb_vector = add_wise.mean(-1).mean(-1)
#         gb_vector = self.fc(gb_vector)
#         gb_vector_FP = self.att_FP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         gb_vector_DP = self.att_DP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         vector = torch.cat((gb_vector_FP, gb_vector_DP), dim=1)
#         vector = self.softmax(vector).unsqueeze(-1).unsqueeze(-1)
#         out = (out * vector).sum(dim=1)
#         out = out + x
#
#         out = self.relu(self.Conv(out))
#         out = self.Conv(out)
#         return out
# class Threshold_Dual_branch_Prior_residual2(nn.Module):
#     def __init__(self, in_channels, out_channels, vector_length, layers_num):
#         super(Threshold_Dual_branch_Prior_residual2, self).__init__()
#         self.Conv = nn.Conv2d(in_channels=in_channels,out_channels=in_channels,kernel_size=3, padding=1,bias=False)
#         self.Feature_Prior = RCAB(channel=in_channels)
#         self.Deep_Prior3 = Deep_Prior(channels=in_channels,layers_num=layers_num)
#         self.fc = nn.Linear(in_features=in_channels,out_features=vector_length)
#         self.att_FP = nn.Linear(in_features=vector_length,out_features=out_channels)
#         self.att_DP = nn.Linear(in_features=vector_length, out_features=out_channels)
#         self.softmax = nn.Softmax(dim=1)
#         self.relu = nn.ReLU(inplace=True)
#     def forward(self, x):
#         input = self.Conv(x)
#         # out1_1 = self.Feature_Prior(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#         out1_1 = self.Feature_Prior(input) ##(25,1,200,26,26)
#         out1 = self.Conv(out1_1).unsqueeze_(dim=1)##(25,200,26,26)
#         out2 = self.Deep_Prior3(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#
#         out = torch.cat((out2, out1), dim=1)  ## 1：按行拼接(行数增加)；0：按列拼接（列数增加） (25,2,200,26,26)
#         add_wise = torch.sum(out, dim=1)  ## 1：横向压缩，将每一行的元素进行相加；0：纵向压缩，将每一列的元素进行相加
#         gb_vector = add_wise.mean(-1).mean(-1)
#         gb_vector = self.fc(gb_vector)
#         gb_vector_FP = self.att_FP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         gb_vector_DP = self.att_DP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         vector = torch.cat((gb_vector_FP, gb_vector_DP), dim=1)
#         vector = self.softmax(vector).unsqueeze(-1).unsqueeze(-1)
#         out = (out * vector).sum(dim=1)
#         out = out + x
#         out = self.relu(self.Conv(out))
#         out = self.Conv(out)
#         return out
# class Threshold_Dual_branch_Prior_residual_single(nn.Module):
#     def __init__(self, in_channels, out_channels, vector_length, layers_num):
#         super(Threshold_Dual_branch_Prior_residual_single, self).__init__()
#         self.Conv = nn.Conv2d(in_channels=in_channels,out_channels=in_channels,kernel_size=3, padding=1,bias=False)
#         self.Feature_Prior = RCAB(channel=in_channels)
#         self.Deep_Prior3 = Deep_Prior(channels=in_channels,layers_num=layers_num)
#         self.fc = nn.Linear(in_features=in_channels,out_features=vector_length)
#         self.att_FP = nn.Linear(in_features=vector_length,out_features=out_channels)
#         self.att_DP = nn.Linear(in_features=vector_length, out_features=out_channels)
#         self.softmax = nn.Softmax(dim=1)
#         self.relu = nn.ReLU(inplace=True)
#     def forward(self, x):
#         input = self.Conv(x)
#         # out1_1 = self.Feature_Prior(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#         out1_1 = self.Feature_Prior(input) ##(25,1,200,26,26)
#         out1 = self.Conv(out1_1).unsqueeze_(dim=1)##(25,200,26,26)
#         out2 = self.Deep_Prior3(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#
#         out = torch.cat((out2, out1), dim=1)  ## 1：按行拼接(行数增加)；0：按列拼接（列数增加） (25,2,200,26,26)
#         add_wise = torch.sum(out, dim=1)  ## 1：横向压缩，将每一行的元素进行相加；0：纵向压缩，将每一列的元素进行相加
#         gb_vector = add_wise.mean(-1).mean(-1)
#         gb_vector = self.fc(gb_vector)
#         gb_vector_FP = self.att_FP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         gb_vector_DP = self.att_DP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         vector = torch.cat((gb_vector_FP, gb_vector_DP), dim=1)
#         vector = self.softmax(vector).unsqueeze(-1).unsqueeze(-1)
#         out = (out * vector).sum(dim=1)
#         out = out + x
#         out = self.relu(self.Conv(out))
#         out = self.relu(self.Conv(out))
#         out = self.relu(self.Conv(out))
#         # out = self.relu(self.Conv(out))
#         out = self.Conv(out)
#         return out
# class Threshold_Dual_Multi_Prior_residual(nn.Module):
#     def __init__(self, in_channels, out_channels, vector_length, layers_num):
#         super(Threshold_Dual_Multi_Prior_residual, self).__init__()
#         self.Conv = nn.Conv2d(in_channels=in_channels,out_channels=in_channels,kernel_size=3, padding=1,bias=False)
#         self.Deep_Prior5 = Deep_Prior5(channels=in_channels,layers_num=layers_num)
#         self.Deep_Prior3 = Deep_Prior(channels=in_channels,layers_num=layers_num)
#         self.fc = nn.Linear(in_features=in_channels,out_features=vector_length)
#         self.att_FP = nn.Linear(in_features=vector_length,out_features=out_channels)
#         self.att_DP = nn.Linear(in_features=vector_length, out_features=out_channels)
#         self.softmax = nn.Softmax(dim=1)
#         self.relu = nn.ReLU(inplace=True)
#     def forward(self, x):
#         input = self.Conv(x)
#         out1 = self.Deep_Prior5(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#         out2 = self.Deep_Prior3(input).unsqueeze_(dim=1) ##(25,1,200,26,26)
#
#         out = torch.cat((out2, out1), dim=1)  ## 1：按行拼接(行数增加)；0：按列拼接（列数增加） (25,2,200,26,26)
#         add_wise = torch.sum(out, dim=1)  ## 1：横向压缩，将每一行的元素进行相加；0：纵向压缩，将每一列的元素进行相加
#         gb_vector = add_wise.mean(-1).mean(-1)
#         gb_vector = self.fc(gb_vector)
#         gb_vector_FP = self.att_FP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         gb_vector_DP = self.att_DP(gb_vector).unsqueeze_(dim=1)  ###全连接
#         vector = torch.cat((gb_vector_FP, gb_vector_DP), dim=1)
#         vector = self.softmax(vector).unsqueeze(-1).unsqueeze(-1)
#         out = (out * vector).sum(dim=1)
#         out = out + x
#
#         out = self.relu(self.Conv(out))
#         out = self.Conv(out)
#         return out
# class Mul_LAB(nn.Module):
#     def __init__(self, channels,M=2,r=2):
#         super(Mul_LAB, self).__init__()
#         self.M = M
#         self.features = channels
#         self.convs = nn.ModuleList([])
#         d = channels//r
#         for i in range(M):
#             if i ==0:
#                 self.convs.append(nn.Sequential(
#                 nn.Conv2d(channels, channels, kernel_size=3, stride=1, padding=1),
#                 # nn.BatchNorm2d(channels),
#                 nn.ReLU(inplace=False)
#             ))
#             else:
#                 self.convs.append(
#                 nn.Sequential(
#                 nn.Conv2d(channels, channels,3,1,1),
#                 # nn.BatchNorm2d(channels),
#                 nn.ReLU(inplace=False),
#                 nn.Conv2d(channels,channels,3,1,1),
#                 # nn.BatchNorm2d(channels),
#                 nn.ReLU(inplace=False)
#                 ))
#         self.fc = nn.Linear(channels, d)
#         self.fcs = nn.ModuleList([])
#         for i in range(M):
#             self.fcs.append(
#                 nn.Linear(d, channels))
#         self.softmax = nn.Softmax(dim=1)
#
#     def forward(self, x):
#         input = x
#         for i, conv in enumerate(self.convs):
#             fea = conv(x).unsqueeze_(dim=1)
#             if i == 0:
#                 feas = fea
#             else:
#                 feas = torch.cat([feas, fea], dim=1)
#         fea_U = torch.sum(feas, dim=1)
#         # fea_s = self.gap(fea_U).squeeze_()
#         fea_s = fea_U.mean(-1).mean(-1)
#         fea_z = self.fc(fea_s)
#         for i, fc in enumerate(self.fcs):
#             vector = fc(fea_z).unsqueeze_(dim=1)
#             if i == 0:
#                 attention_vectors = vector
#             else:
#                 attention_vectors = torch.cat([attention_vectors, vector], dim=1)
#         attention_vectors = self.softmax(attention_vectors)
#         attention_vectors = attention_vectors.unsqueeze(-1).unsqueeze(-1)
#         fea_v = (feas * attention_vectors).sum(dim=1)
#         output = input + fea_v
#         return output
# class Mul_LAB_enhance(nn.Module):
#     def __init__(self, channels,M=2,r=2):
#         super(Mul_LAB_enhance, self).__init__()
#         self.M = M
#         self.features = channels
#         self.convs = nn.ModuleList([])
#         d = channels//r
#         for i in range(M):
#             if i ==0:
#                 self.convs.append(nn.Sequential(
#                 nn.Conv2d(channels, channels, kernel_size=3, stride=1, padding=1),
#                 # nn.BatchNorm2d(channels),
#                 nn.ReLU(inplace=False)
#             ))
#             else:
#                 self.convs.append(
#                 nn.Sequential(
#                 nn.Conv2d(channels, channels,3,1,1),
#                 # nn.BatchNorm2d(channels),
#                 nn.ReLU(inplace=False),
#                 nn.Conv2d(channels,channels,3,1,1),
#                 # nn.BatchNorm2d(channels),
#                 nn.ReLU(inplace=False),
#                 nn.Conv2d(channels, channels, 3, 1, 1),
#                 # nn.BatchNorm2d(channels),
#                 nn.ReLU(inplace=False)
#                 ))
#         self.fc = nn.Linear(channels, d)
#         self.fcs = nn.ModuleList([])
#         for i in range(M):
#             self.fcs.append(
#                 nn.Linear(d, channels))
#         self.softmax = nn.Softmax(dim=1)
#
#     def forward(self, x):
#         input = x
#         for i, conv in enumerate(self.convs):
#             fea = conv(x).unsqueeze_(dim=1)
#             if i == 0:
#                 feas = fea
#             else:
#                 feas = torch.cat([feas, fea], dim=1)
#         fea_U = torch.sum(feas, dim=1)
#         # fea_s = self.gap(fea_U).squeeze_()
#         fea_s = fea_U.mean(-1).mean(-1)
#         fea_z = self.fc(fea_s)
#         for i, fc in enumerate(self.fcs):
#             vector = fc(fea_z).unsqueeze_(dim=1)
#             if i == 0:
#                 attention_vectors = vector
#             else:
#                 attention_vectors = torch.cat([attention_vectors, vector], dim=1)
#         attention_vectors = self.softmax(attention_vectors)
#         attention_vectors = attention_vectors.unsqueeze(-1).unsqueeze(-1)
#         fea_v = (feas * attention_vectors).sum(dim=1)
#         output = input + fea_v
#         return output
# class Threshold_Multi_scale_local_attention(nn.Module):
#     def __init__(self, channels, layers_num):
#         super(Threshold_Multi_scale_local_attention, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         layers.append(nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, padding=padding,bias=False))
#         for _ in range(self.depth - 1):
#             layers.append(Mul_LAB(channels=channels,M=2,r=2))
#         layers.append(nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, padding=padding,bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class Threshold_Multi_scale_local_attention_enhance(nn.Module):
#     def __init__(self, channels, layers_num):
#         super(Threshold_Multi_scale_local_attention_enhance, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         layers.append(nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, padding=padding,bias=False))
#         for _ in range(self.depth - 1):
#             layers.append(Mul_LAB_enhance(channels=channels,M=2,r=2))
#         layers.append(nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, padding=padding,bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class M_RSAN(nn.Module):
#     def __init__(self,channels, layers_num): ##layers_num=3
#         super(M_RSAN, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         for i in range(self.depth-2):
#             layers.append(M_RSAB(channel=channels))
#         layers.append(nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
#         layers.append(nn.ReLU(inplace=True))
#         layers.append(nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, padding=padding,bias=False))
#
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
# class M_RSAN_shared(nn.Module):
#     def __init__(self,channels, layers_num):
#         super(M_RSAN_shared, self).__init__()
#         self.depth = layers_num
#         layers = []
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         for i in range(self.depth-1):
#             layers.append(M_RSAB_shared(channel=channels))
#         layers.append(nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self, x):
#         epsilon = self.epsilon_net(x)
#         return epsilon
#
# class CNN(nn.Module):
#     def __init__(self,channels, layers_num=4):
#         super(CNN, self).__init__()
#         layers = []
#         self.depth = layers_num
#         kernel_size = 3  ### 卷积核大小
#         padding = 1  # 填充
#         features = 200  ### feature map的数量
#         for _ in range(self.depth - 1):
#             layers.append(nn.Conv2d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding,bias=False))  ### 卷积
#             layers.append(nn.ReLU(inplace=True))  ## Relu
#         layers.append(nn.Conv2d(in_channels=features, out_channels=channels, kernel_size=kernel_size, padding=padding, bias=False))
#
#         self.epsilon_net = nn.Sequential(*layers)
#     def forward(self,x):
#         out = self.epsilon_net(x)
#         return out
# class Threshold_Image_and_Coefficient(nn.Module):
#     def __init__(self,channels, layers_num=1):
#         super(Threshold_Image_and_Coefficient, self).__init__()
#         self.RCAB_C = RCAB(channel=channels)
#         self.RCAB_I = RCAB_I(channel=channels)
#         self.Conv = nn.Conv2d(1, 1, kernel_size=13, stride=5,bias=False)
#         self.Conv1 = nn.Conv2d(channels+1, out_channels=channels, kernel_size=1, padding=0,bias=False)
#         self.CNN = CNN(channels=channels,layers_num=layers_num)
#     def forward(self, C, I):
#         C_feature = self.RCAB_C(C)
#         I_feature = self.RCAB_I(I)
#         I_feature2 = self.Conv(I_feature)
#         temp = torch.cat([C_feature, I_feature2], 1)
#         temp1 = self.Conv1(temp)
#         epsilon = self.CNN(temp1)
#         return epsilon
## threshold_initial

class SoftThreshold0(nn.Module):
    def __init__(self, size, init_threshold=1e-3):
        super(SoftThreshold0, self).__init__()
        self.threshold = nn.Parameter(init_threshold * torch.ones(1,size,1,1))
    def forward(self, x):
        mask1 = (x > self.threshold).float()
        mask2 = (x < -self.threshold).float()
        out = mask1.float() * (x - self.threshold)
        out += mask2.float() * (x + self.threshold)
        return out
class SoftThreshold(nn.Module):
    def __init__(self, threshold):
        super(SoftThreshold, self).__init__()
        # self.threshold = nn.Parameter(threshold)
        self.threshold = threshold
    def forward(self, b, threshold):
        z = torch.sign(b) * torch.max(torch.abs(b) - threshold, torch.zeros(b.shape).cuda())
        return z

## 选择特定的特征：特征注意力"""
class SELayer(nn.Module):                                           #select the essential features
    def __init__(self, channel, reduction=1):  # 16
        super(SELayer, self).__init__()
        self.depth = 2
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel),
            nn.Sigmoid()  # sigmoid
        )
    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x ** 2).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y
## Residual Channel Attention Block (RCAB)
class RCAB(nn.Module):
    def __init__(
        self, channel, kernel_size=3, reduction=1,
        bias=True,act=nn.ReLU(True), res_scale=1):

        super(RCAB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(nn.Conv2d(channel, channel, kernel_size, padding=1, bias=bias))
            if i == 0: modules_body.append(act)
        modules_body.append(SELayer(channel, reduction))
        self.body = nn.Sequential(*modules_body)
        self.res_scale = res_scale
    def forward(self, x):
        res = self.body(x)
        #res = self.body(x).mul(self.res_scale)
        res += x
        return res
class RCAB_I(nn.Module):
    def __init__(
        self, channel, kernel_size=3, reduction=1,
        bias=True,act=nn.ReLU(True), res_scale=1):

        super(RCAB_I, self).__init__()
        modules_body = []
        modules_body.append(nn.Conv2d(1, channel, kernel_size, padding=1, bias=bias))
        modules_body.append(act)
        modules_body.append(nn.Conv2d(channel, channel, kernel_size, padding=1, bias=bias))
        modules_body.append(SELayer(channel, reduction))
        self.body = nn.Sequential(*modules_body)
        self.conv = nn.Conv2d(channel, 1,kernel_size, padding=1, bias=bias)
        self.res_scale = res_scale
    def forward(self, x):
        temp = self.body(x)
        res = self.conv(temp)
        #res = self.body(x).mul(self.res_scale)
        res += x
        return res
## Multi
class M_RCAB(nn.Module):
    def __init__(self, channel):
        super(M_RCAB, self).__init__()

        kernel_size_1 = 3
        kernel_size_2 = 5

        self.conv_3 = nn.Conv2d(channel, channel, kernel_size_1, padding=(kernel_size_1//2), bias=True)
        self.conv_5 = nn.Conv2d(channel, channel, kernel_size_2, padding=(kernel_size_2//2), bias=True)
        self.confusion = nn.Conv2d(channel * 2, channel, 1, padding=0, stride=1)
        self.relu = nn.ReLU(inplace=True)
        self.RCAB = RCAB(channel)

    def forward(self, x):

        input_1 = x
        output_3 = self.relu(self.conv_3(input_1))
        output_5 = self.relu(self.conv_5(input_1))
        output_3_RCAB = self.RCAB(output_3)
        output_5_RCAB = self.RCAB(output_5)
        output = torch.cat([output_3_RCAB, output_5_RCAB], 1)
        output = self.confusion(output)
        output += x
        return output
## Multi2
class M_RCAB2(nn.Module):
    def __init__(self, channel):
        super(M_RCAB2, self).__init__()

        kernel_size_1 = 3
        kernel_size_2 = 5

        self.conv_3 = nn.Conv2d(channel, channel, kernel_size_1, padding=(kernel_size_1//2), bias=True)
        self.conv_5 = nn.Conv2d(channel, channel, kernel_size_2, padding=(kernel_size_2//2), bias=True)
        self.confusion = nn.Conv2d(channel * 2, channel, 1, padding=0, stride=1)
        self.relu = nn.ReLU(inplace=True)
        self.RCAB = RCAB(channel)

    def forward(self, x):

        input_1 = x
        output_3 = self.relu(self.conv_3(input_1))
        output_5 = self.relu(self.conv_5(input_1))
        output_3_RCAB = self.RCAB(output_3)
        output_5_RCAB = self.RCAB(output_5)
        output_3_RCAB2 = self.conv_3(output_3_RCAB)
        output_5_RCAB2 = self.conv_3(output_5_RCAB)
        output = torch.cat([output_3_RCAB2, output_5_RCAB2], 1)
        output = self.confusion(output)
        output += x
        return output
## Multi residual
class M_RSAB(nn.Module):
    def __init__(self, channel):
        super(M_RSAB, self).__init__()

        kernel_size_1 = 3
        kernel_size_2 = 5

        self.conv_3 = nn.Conv2d(channel, channel, kernel_size_1, padding=(kernel_size_1//2), bias=True)
        self.conv_5 = nn.Conv2d(channel, channel, kernel_size_2, padding=(kernel_size_2//2), bias=True)
        self.confusion = nn.Conv2d(channel * 2, channel, 1, padding=0, stride=1)
        self.relu = nn.ReLU(inplace=True)
        self.RCAB = RCAB(channel)

    def forward(self, x):

        input_1 = x
        output_3 = self.relu(self.conv_3(input_1))
        output_5 = self.relu(self.conv_5(input_1))
        output_3_RCAB = self.RCAB(output_3)
        output_5_RCAB = self.RCAB(output_5)
        output_3_RCAB2 = self.conv_3(output_3_RCAB)
        output_5_RCAB2 = self.conv_5(output_5_RCAB)
        output = torch.cat([output_3_RCAB2, output_5_RCAB2], 1)
        output = self.confusion(output)
        output += x
        return output
## Multi residual shared
class M_RSAB_shared(nn.Module):
    def __init__(self, channel):
        super(M_RSAB_shared, self).__init__()

        kernel_size_1 = 3
        kernel_size_2 = 5

        self.conv_3_1 = nn.Conv2d(channel, channel, kernel_size_1, padding=(kernel_size_1//2), bias=True)
        self.conv_5_1 = nn.Conv2d(channel, channel, kernel_size_2, padding=(kernel_size_2//2), bias=True)
        self.conv_3_2 = nn.Conv2d(channel*2, channel*2, kernel_size_1, padding=(kernel_size_1 // 2), bias=True)
        self.conv_5_2 = nn.Conv2d(channel*2, channel*2, kernel_size_2, padding=(kernel_size_2 // 2), bias=True)
        self.confusion = nn.Conv2d(channel * 4, channel, 1, padding=0, stride=1)
        self.relu = nn.ReLU(inplace=True)
        self.RCAB = RCAB(channel)

    def forward(self, x):

        input_1 = x
        output_3_1 = self.relu(self.conv_3_1(input_1))
        output_5_1 = self.relu(self.conv_5_1(input_1))
        # input_2 = torch.cat([output_3_1, output_5_1], 1)
        output_3_RCAB = self.RCAB(output_3_1)
        output_5_RCAB = self.RCAB(output_5_1)
        input_2 = torch.cat([output_3_RCAB, output_5_RCAB], 1)
        output_3_2 = self.relu(self.conv_3_2(input_2))
        output_5_2 = self.relu(self.conv_5_2(input_2))
        input_3 = torch.cat([output_3_2, output_5_2], 1)
        output = self.confusion(input_3)
        output += x
        return output

ListaParams = namedtuple('ListaParams', ['kernel_size', 'num_filters', 'stride', 'unfoldings', 'beta','epsilon'])
ListaParams_iteration = namedtuple('ListaParams', ['kernel_size', 'num_filters', 'stride', 'unfoldings', 'beta','tau','epsilon'])
ListaParams_nobeta= namedtuple('ListaParams', ['kernel_size', 'num_filters', 'stride', 'unfoldings','epsilon'])
ListaParams_grad = namedtuple('ListaParams', ['kernel_size', 'num_filters', 'stride', 'unfoldings','epsilon', 'step_size'])
class ConvLista_T_learning(nn.Module):
    def __init__(self, params: ListaParams, A=None, B=None, C=None):
        super(ConvLista_T_learning, self).__init__()
        if A is None:
            A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
            l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
            A /= torch.sqrt(l)
        if B is None:
            B = torch.clone(A)
        if C is None:
            C = torch.clone(A)
        # if threshold is None:
        #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
        self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
        self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_A.weight.data = A
        self.apply_B.weight.data = B
        self.apply_C.weight.data = C
        self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
        self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
        ### self.threshold=threshold(老师标志的)
        self.params = params
    def _split_image(self, I):
        if self.params.stride == 1:
            return I, torch.ones_like(I)
        left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
        I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
                                       left_pad + I.shape[3] + right_pad).type_as(I)
        valids_batched = torch.zeros_like(I_batched_padded)
        for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
            I_padded = functional.pad(I, pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
            valids = functional.pad(torch.ones_like(I), pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
            I_batched_padded[:, num, :, :, :] = I_padded
            valids_batched[:, num, :, :, :] = valids
        I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
        valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
        return I_batched_padded, valids_batched

    def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
        I_batched_padded, valids_batched = self._split_image(I)
        if iteration == 0:
            conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
            gamma_k = self.soft_threshold0(conv_input)
        for k in range(self.params.unfoldings - 1):
            x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
            r_k = self.apply_B(x_k - I_batched_padded)
            gamma_k = self.soft_threshold0(gamma_k-r_k) #learn
        # print(e)
        output_all = self.apply_C(gamma_k)
        output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
        # if self.return_all:
        #     return output_cropped
        output = output_cropped.mean(dim=1, keepdim=False)
        return output, gamma_k
# class ConvLista_T_updating(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_updating, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net(channels=200, layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention_residual(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention_residual, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention_residual(channels=200, layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
class ConvLista_T_attention1(nn.Module):
    def __init__(self, params: ListaParams, A=None, B=None, C=None):
        super(ConvLista_T_attention1, self).__init__()
        if A is None:
            A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
            l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
            A /= torch.sqrt(l)
        if B is None:
            B = torch.clone(A)
        if C is None:
            C = torch.clone(A)
        # if threshold is None:
        #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
        self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
        self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_A.weight.data = A
        self.apply_B.weight.data = B
        self.apply_C.weight.data = C
        self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
        self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
        self.threshold = Threshold_net_attention1(channels=200, layers_num=4).cuda()
        self.soft_threshold = SoftThreshold(self.threshold)
        self.params = params
    def _split_image(self, I):
        if self.params.stride == 1:
            return I, torch.ones_like(I)
        left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
        I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
                                       left_pad + I.shape[3] + right_pad).type_as(I)
        valids_batched = torch.zeros_like(I_batched_padded)
        for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
            I_padded = functional.pad(I, pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
            valids = functional.pad(torch.ones_like(I), pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
            I_batched_padded[:, num, :, :, :] = I_padded
            valids_batched[:, num, :, :, :] = valids
        I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
        valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
        return I_batched_padded, valids_batched

    def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
        I_batched_padded, valids_batched = self._split_image(I)
        if iteration == 0:
            conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
            gamma_k = self.soft_threshold0(conv_input)
        for k in range(self.params.unfoldings - 1):
            epsilon = self.threshold(gamma_k)
            x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
            r_k = self.apply_B(x_k - I_batched_padded)
            gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
        # print(e)
        output_all = self.apply_C(gamma_k)
        output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
        # if self.return_all:
        #     return output_cropped
        output = output_cropped.mean(dim=1, keepdim=False)
        # feature_map = self.apply_C.weight.data.detach().cpu()
        # for i in range(feature_map.size(1)):
        #     plt.matshow(feature_map[0, i, :, :], cmap="gray")
        #     plt.draw()
        #     plt.pause(0.1)
        #     plt.close()
        # Dc = self.apply_C.weight.data
        return output, gamma_k

class ConvLista_T_iteration(nn.Module):
    def __init__(self, params: ListaParams, A=None, B=None, C=None):
        super(ConvLista_T_iteration, self).__init__()
        if A is None:
            A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
            l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
            A /= torch.sqrt(l)
        if B is None:
            B = torch.clone(A)
        if C is None:
            C = torch.clone(A)
        # if threshold is None:
        #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
        self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
        self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_A.weight.data = A
        self.apply_B.weight.data = B
        self.apply_C.weight.data = C
        self.tau = nn.Parameter(torch.FloatTensor([params.tau]), requires_grad=True)
        self.epsilon = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
        # self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
        self.soft_threshold = SoftThreshold(self.epsilon)
        self.params = params
    def _split_image(self, I):
        if self.params.stride == 1:
            return I, torch.ones_like(I)
        left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
        I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
                                       left_pad + I.shape[3] + right_pad).type_as(I)
        valids_batched = torch.zeros_like(I_batched_padded)
        for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
            I_padded = functional.pad(I, pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
            valids = functional.pad(torch.ones_like(I), pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
            I_batched_padded[:, num, :, :, :] = I_padded
            valids_batched[:, num, :, :, :] = valids
        I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
        valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
        return I_batched_padded, valids_batched

    def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
        I_batched_padded, valids_batched = self._split_image(I)
        if iteration == 0:
            conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
            omega = self.tau / (abs(conv_input) + self.epsilon)
            gamma_k = self.soft_threshold(conv_input, omega)
        for k in range(self.params.unfoldings - 1):
            x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
            r_k = self.apply_B(x_k - I_batched_padded)
            omega = self.tau / (abs(r_k) + self.epsilon)
            gamma_k = self.soft_threshold(gamma_k - r_k,omega) #net
        # print(e)
        output_all = self.apply_C(gamma_k)
        output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
        # if self.return_all:
        #     return output_cropped
        output = output_cropped.mean(dim=1, keepdim=False)
        # feature_map = self.apply_C.weight.data.detach().cpu()
        # for i in range(feature_map.size(1)):
        #     plt.matshow(feature_map[0, i, :, :], cmap="gray")
        #     plt.draw()
        #     plt.pause(0.1)
        #     plt.close()
        # Dc = self.apply_C.weight.data
        return output, gamma_k

class ConvLista_T_attention1_grad_add(nn.Module):
    def __init__(self, params: ListaParams, A=None, B=None, C=None):
        super(ConvLista_T_attention1_grad_add, self).__init__()
        if A is None:
            A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
            l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
            A /= torch.sqrt(l)
        if B is None:
            B = torch.clone(A)
        if C is None:
            C = torch.clone(A)
        # if threshold is None:
        #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
        self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
        self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_A.weight.data = A
        self.apply_B.weight.data = B
        self.apply_C.weight.data = C
        self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
        self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
        self.threshold = Threshold_net_attention1(channels=200, layers_num=4).cuda()
        self.soft_threshold = SoftThreshold(self.threshold)
        self.params = params
    def _split_image(self, I):
        if self.params.stride == 1:
            return I, torch.ones_like(I)
        left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
        I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
                                       left_pad + I.shape[3] + right_pad).type_as(I)
        valids_batched = torch.zeros_like(I_batched_padded)
        for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
            I_padded = functional.pad(I, pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
            valids = functional.pad(torch.ones_like(I), pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
            I_batched_padded[:, num, :, :, :] = I_padded
            valids_batched[:, num, :, :, :] = valids
        I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
        valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
        return I_batched_padded, valids_batched

    def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
        I_batched_padded, valids_batched = self._split_image(I)
        if iteration == 0:
            conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
            gamma_k = self.soft_threshold0(conv_input)
        for k in range(self.params.unfoldings - 1):
            epsilon = self.threshold(gamma_k)
            x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
            r_k = self.apply_B(x_k - I_batched_padded)
            gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
        # print(e)
        output_all = self.apply_C(gamma_k)
        output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
        # if self.return_all:
        #     return output_cropped
        output = output_cropped.mean(dim=1, keepdim=False)
        # feature_map = self.apply_C.weight.data.detach().cpu()
        # for i in range(feature_map.size(1)):
        #     plt.matshow(feature_map[0, i, :, :], cmap="gray")
        #     plt.draw()
        #     plt.pause(0.1)
        #     plt.close()
        # Dc = self.apply_C.weight.data
        return output, gamma_k

class ConvLista_T_attention2_grad_10_5_00001001(nn.Module):
    def __init__(self, params: ListaParams, A=None, B=None, C=None):
        super(ConvLista_T_attention2_grad_10_5_00001001, self).__init__()
        if A is None:
            A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
            l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
            A /= torch.sqrt(l)
        if B is None:
            B = torch.clone(A)
        if C is None:
            C = torch.clone(A)
        # if threshold is None:
        #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
        self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
        self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
                                                stride=params.stride, bias=False)
        self.apply_A.weight.data = A
        self.apply_B.weight.data = B
        self.apply_C.weight.data = C
        self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
        self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
        self.threshold = Threshold_net_attention2(channels=200, layers_num=4).cuda()
        self.soft_threshold = SoftThreshold(self.threshold)
        self.params = params
    def _split_image(self, I):
        if self.params.stride == 1:
            return I, torch.ones_like(I)
        left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
        I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
                                       left_pad + I.shape[3] + right_pad).type_as(I)
        valids_batched = torch.zeros_like(I_batched_padded)
        for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
            I_padded = functional.pad(I, pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
            valids = functional.pad(torch.ones_like(I), pad=(
                left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
            I_batched_padded[:, num, :, :, :] = I_padded
            valids_batched[:, num, :, :, :] = valids
        I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
        valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
        return I_batched_padded, valids_batched

    def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
        I_batched_padded, valids_batched = self._split_image(I)
        if iteration == 0:
            conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
            gamma_k = self.soft_threshold0(conv_input)
        for k in range(self.params.unfoldings - 1):
            epsilon = self.threshold(gamma_k)
            x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
            r_k = self.apply_B(x_k - I_batched_padded)
            gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
        # print(e)
        output_all = self.apply_C(gamma_k)
        output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
        # if self.return_all:
        #     return output_cropped
        output = output_cropped.mean(dim=1, keepdim=False)
        # feature_map = self.apply_C.weight.data.detach().cpu()
        # for i in range(feature_map.size(1)):
        #     plt.matshow(feature_map[0, i, :, :], cmap="gray")
        #     plt.draw()
        #     plt.pause(0.1)
        #     plt.close()
        # Dc = self.apply_C.weight.data
        return output, gamma_k
# class ConvLista_T_attention1_Add(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention1_Add, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention1_Add(channels=200, layers_num=5).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention1_reduce(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention1_reduce, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention1_reduce(channels=200, layers_num=3).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention3(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention3, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention3(channels=200, layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention_residual2(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention_residual2, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention_residual2(channels=200, layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention_residual2_add(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention_residual2_add, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention_residual2_add(channels=200).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention_dense(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention_dense, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention_dense(channels=200, num_convs=3).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention_dense_residual(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention_dense_residual, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention_dense_residual(channels=200, num_convs=3).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention_residual_Multi(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention_residual_Multi, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention_residual_Multi(channels=200, layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention_residual_Multi_residual(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention_residual_Multi_residual, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention_residual_Multi_residual(channels=200, layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention_residual_Multi_residual2(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention_residual_Multi_residual2, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention_residual_Multi_residual2(channels=200, layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_attention_residual_Multi_two(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_attention_residual_Multi_two, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_net_attention_residual_Multi_two(channels=200, layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_Multi_scale_attention(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Multi_scale_attention, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = M_RSAN(channels=200,layers_num=3).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_Multi_scale_attention_shared(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Multi_scale_attention_shared, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = M_RSAN_shared(channels=200,layers_num=3).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_Dual_branch_Prior(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Dual_branch_Prior, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_Dual_branch_Prior(in_channels=200,out_channels=200,vector_length=100,layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_Dual_branch_Prior_residual(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Dual_branch_Prior_residual, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_Dual_branch_Prior_residual(in_channels=200,out_channels=200,vector_length=100,layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_Dual_branch_Prior_residual2(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Dual_branch_Prior_residual2, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_Dual_branch_Prior_residual2(in_channels=200,out_channels=200,vector_length=100,layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_Dual_Multi_Prior_residual(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Dual_Multi_Prior_residual, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_Dual_Multi_Prior_residual(in_channels=200,out_channels=200,vector_length=100,layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_Dual_branch_Prior_residual_single(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Dual_branch_Prior_residual_single, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_Dual_branch_Prior_residual_single(in_channels=200,out_channels=200,vector_length=100,layers_num=4).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_Multi_scale_local_attention(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Multi_scale_local_attention, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_Multi_scale_local_attention(channels=200,layers_num=3).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
# class ConvLista_T_Multi_scale_local_attention_enhance(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Multi_scale_local_attention_enhance, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_Multi_scale_local_attention_enhance(channels=200,layers_num=3).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, I):
#         if self.params.stride == 1:
#             return I, torch.ones_like(I)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(I, self.params.kernel_size, self.params.stride)
#         I_batched_padded = torch.zeros(I.shape[0], self.params.stride ** 2, I.shape[1], top_pad + I.shape[2] + bot_pad,
#                                        left_pad + I.shape[3] + right_pad).type_as(I)
#         valids_batched = torch.zeros_like(I_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             I_padded = functional.pad(I, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(I), pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             I_batched_padded[:, num, :, :, :] = I_padded
#             valids_batched[:, num, :, :, :] = valids
#         I_batched_padded = I_batched_padded.reshape(-1, *I_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return I_batched_padded, valids_batched
#
#     def forward(self, I, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         I_batched_padded, valids_batched = self._split_image(I)
#         if iteration == 0:
#             conv_input = self.apply_B(I_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,1,138,138)
#             r_k = self.apply_B(x_k - I_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(I.shape[0], self.params.stride ** 2, *I.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
#
# class ConvLista_T_Image_and_Coefficient(nn.Module):
#     def __init__(self, params: ListaParams, A=None, B=None, C=None):
#         super(ConvLista_T_Image_and_Coefficient, self).__init__()
#         if A is None:
#             A = torch.randn(params.num_filters, 1, params.kernel_size, params.kernel_size)
#             l = conv_power_method(A, [512, 512], num_iters=200, stride=params.stride)# Finds the maximal eigenvalue of D.T.dot(D) using the iterative power method
#             A /= torch.sqrt(l)
#         if B is None:
#             B = torch.clone(A)
#         if C is None:
#             C = torch.clone(A)
#         # if threshold is None:
#         #     threshold = 0.01 * torch.ones(params.stride*params.stride, params.num_filters,params.kernel_size*2,params.kernel_size*2)
#         self.apply_A = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_B = torch.nn.Conv2d(1, params.num_filters, kernel_size=params.kernel_size, stride=params.stride, bias=False)#卷积
#         self.apply_C = torch.nn.ConvTranspose2d(params.num_filters, 1, kernel_size=params.kernel_size,
#                                                 stride=params.stride, bias=False)
#         self.apply_A.weight.data = A
#         self.apply_B.weight.data = B
#         self.apply_C.weight.data = C
#         self.threshold0 = nn.Parameter(torch.FloatTensor([params.epsilon]), requires_grad=True)
#         self.soft_threshold0 = SoftThreshold0(params.num_filters, self.threshold0) #threshold initial
#         self.threshold = Threshold_Image_and_Coefficient(channels=200,layers_num=1).cuda()
#         self.soft_threshold = SoftThreshold(self.threshold)
#         self.params = params
#     def _split_image(self, C):
#         if self.params.stride == 1:
#             return C, torch.ones_like(C)
#         left_pad, right_pad, top_pad, bot_pad = calc_pad_sizes(C, self.params.kernel_size, self.params.stride)
#         C_batched_padded = torch.zeros(C.shape[0], self.params.stride ** 2, C.shape[1], top_pad + C.shape[2] + bot_pad,
#                                        left_pad + C.shape[3] + right_pad).type_as(C)
#         valids_batched = torch.zeros_like(C_batched_padded)
#         for num, (row_shift, col_shift) in enumerate([(i, j) for i in range(self.params.stride) for j in range(self.params.stride)]):
#             C_padded = functional.pad(C, pad=(
#                 left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='reflect')
#             valids = functional.pad(torch.ones_like(C), pad=(left_pad - col_shift, right_pad + col_shift, top_pad - row_shift, bot_pad + row_shift), mode='constant')
#             C_batched_padded[:, num, :, :, :] = C_padded
#             valids_batched[:, num, :, :, :] = valids
#         C_batched_padded = C_batched_padded.reshape(-1, *C_batched_padded.shape[2:])
#         valids_batched = valids_batched.reshape(-1, *valids_batched.shape[2:])
#         return C_batched_padded, valids_batched
#
#     def forward(self,C, gamma_k, iteration):#iteration:表示第几层网络（一共8层）
#         C_batched_padded, valids_batched = self._split_image(C)
#         if iteration == 0:
#             conv_input = self.apply_B(C_batched_padded)  ##conv_input的大小为(25,200,26,26)
#             gamma_k = self.soft_threshold0(conv_input) ##(25,200,26,26)
#         for k in range(self.params.unfoldings - 1):
#             epsilon = self.threshold(gamma_k,C_batched_padded)
#             x_k = self.apply_A(gamma_k)     ##x_k 的大小为(25,200,138,138)
#             r_k = self.apply_B(x_k - C_batched_padded)
#             gamma_k = self.soft_threshold(gamma_k - r_k,epsilon) #net
#         # print(e)
#         output_all = self.apply_C(gamma_k)
#         output_cropped = torch.masked_select(output_all, valids_batched.byte()).reshape(C.shape[0], self.params.stride ** 2, *C.shape[1:])
#         # if self.return_all:
#         #     return output_cropped
#         output = output_cropped.mean(dim=1, keepdim=False)
#         return output, gamma_k
#
